@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Moon Animator 2 installer
set "MOON_ANIMATOR_INSTALL_DIR=%~dp0"
set "MOON_ANIMATOR_INSTALL_SHA256=bc87d948e6678a6e050a834f3f69ea23b1f8b0340926589b7d8794a7fb14a37b"
echo Moon Animator 2 - offline installer
echo Close Roblox Studio before installing. No administrator access is needed.
echo.
rem Paths stay in environment variables; they are never inserted into PowerShell code.
rem Each quoted fragment below is part of one readable PowerShell command.
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -NonInteractive -Command ^
  "$ErrorActionPreference = 'Stop'; $stage = $null; $status = 1;" ^
  "function Assert-PlainPath([string] $path) {" ^
  "  $current = [IO.Path]::GetFullPath($path);" ^
  "  while ($current) {" ^
  "    $attributes = $null;" ^
  "    try { $attributes = [IO.File]::GetAttributes($current) }" ^
  "    catch [IO.FileNotFoundException] {} catch [IO.DirectoryNotFoundException] {};" ^
  "    if ($null -ne $attributes -and ($attributes -band [IO.FileAttributes]::ReparsePoint)) { throw ('Linked/junction paths are not supported: ' + $current) };" ^
  "    $parent = [IO.Directory]::GetParent($current);" ^
  "    if ($null -eq $parent) { break }; $current = $parent.FullName;" ^
  "  };" ^
  "};" ^
  "function Get-Hash([string] $path) {" ^
  "  $stream = $null; $algorithm = $null;" ^
  "  try { $stream = [IO.File]::OpenRead($path); $algorithm = [Security.Cryptography.SHA256]::Create();" ^
  "    return [BitConverter]::ToString($algorithm.ComputeHash($stream)).Replace('-', '').ToLowerInvariant();" ^
  "  } finally { if ($algorithm) { $algorithm.Dispose() }; if ($stream) { $stream.Dispose() } };" ^
  "};" ^
  "function Assert-StudioClosed {" ^
  "  $running = @(Get-Process -ErrorAction Stop | Where-Object { $_.ProcessName -like 'RobloxStudio*' });" ^
  "  if ($running.Count -gt 0) { throw 'Close Roblox Studio, then double-click Install.cmd again.' };" ^
  "};" ^
  "try {" ^
  "  if ($env:MOON_ANIMATOR_INSTALL_DIR -notmatch '^[A-Za-z]:\\' -or $env:LOCALAPPDATA -notmatch '^[A-Za-z]:\\') { throw 'Use an extracted folder and a LOCALAPPDATA folder on a local Windows drive.' };" ^
  "  $source = Join-Path $env:MOON_ANIMATOR_INSTALL_DIR 'Moon_Animator_2_review_candidate.rbxm';" ^
  "  $expected = $env:MOON_ANIMATOR_INSTALL_SHA256;" ^
  "  Assert-PlainPath $source;" ^
  "  if (-not [IO.File]::Exists($source)) { throw 'The plugin file is missing. Extract all three files from the ZIP into one folder first.' };" ^
  "  if ((Get-Hash $source) -ne $expected) { throw 'The plugin SHA256 does not match this installer. Extract a fresh copy of the complete ZIP.' };" ^
  "  $localRoot = [IO.Path]::GetFullPath($env:LOCALAPPDATA);" ^
  "  $plugins = Join-Path $localRoot 'Roblox\Plugins';" ^
  "  $destination = Join-Path $plugins 'Moon_Animator_2_review_candidate.rbxm';" ^
  "  $backupDir = Join-Path $localRoot 'MoonAnimator2\Backups';" ^
  "  Assert-PlainPath $destination; Assert-PlainPath $backupDir;" ^
  "  if ([IO.Directory]::Exists($destination)) { throw 'A directory occupies the managed plugin filename. Installation stopped.' };" ^
  "  Assert-StudioClosed;" ^
  "  [void] [IO.Directory]::CreateDirectory($plugins); Assert-PlainPath $plugins;" ^
  "  $stage = Join-Path $plugins ('.moon-animator-install-' + [guid]::NewGuid().ToString('N') + '.tmp');" ^
  "  [IO.File]::Copy($source, $stage, $false); Assert-PlainPath $stage;" ^
  "  if ((Get-Hash $stage) -ne $expected) { throw 'The staged plugin failed its SHA256 check. Installation stopped.' };" ^
  "  if ([IO.File]::Exists($destination)) {" ^
  "    [void] [IO.Directory]::CreateDirectory($backupDir); Assert-PlainPath $backupDir; Assert-PlainPath $destination;" ^
  "    $backup = Join-Path $backupDir ('Moon_Animator_2_' + [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffffffZ') + '_' + [guid]::NewGuid().ToString('N') + '.rbxm.bak');" ^
  "    $previousHash = Get-Hash $destination; [IO.File]::Copy($destination, $backup, $false);" ^
  "    if ((Get-Hash $backup) -ne $previousHash) { throw 'The existing plugin could not be backed up correctly. Installation stopped.' };" ^
  "    Write-Host ('Backup saved: ' + $backup);" ^
  "    Assert-PlainPath $destination; Assert-PlainPath $stage; Assert-StudioClosed;" ^
  "    [IO.File]::Replace($stage, $destination, [System.Management.Automation.Language.NullString]::Value);" ^
  "  } else {" ^
  "    Assert-PlainPath $destination; Assert-PlainPath $stage; Assert-StudioClosed;" ^
  "    [IO.File]::Move($stage, $destination);" ^
  "  };" ^
  "  $stage = $null;" ^
  "  if ((Get-Hash $destination) -ne $expected) { throw 'The installed plugin failed its final SHA256 check.' };" ^
  "  Write-Host ('SUCCESS: Installed ' + $destination);" ^
  "  Write-Host 'Open Roblox Studio and find Moon Animator 2 in the Plugins tab.'; $status = 0;" ^
  "} catch { Write-Host ('ERROR: ' + $_.Exception.Message);" ^
  "} finally {" ^
  "  if ($stage -and [IO.File]::Exists($stage)) { try { Assert-PlainPath $stage; [IO.File]::Delete($stage) } catch { Write-Host ('Temporary file could not be removed: ' + $stage) } };" ^
  "}; exit $status"
set "MOON_ANIMATOR_INSTALL_STATUS=%ERRORLEVEL%"
echo.
if not "%MOON_ANIMATOR_INSTALL_STATUS%"=="0" echo Installation did not finish. Read the error above; no admin or policy change is needed.
pause
exit /b %MOON_ANIMATOR_INSTALL_STATUS%
